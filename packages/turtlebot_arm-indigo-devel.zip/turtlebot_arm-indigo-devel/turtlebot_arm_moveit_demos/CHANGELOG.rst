^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_arm_moveit_demos
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.3 (2014-09-20)
------------------

0.3.2 (2014-08-30)
------------------
* Use base_link instead of base_footprint as the reference "fixed" frame

0.3.1 (2014-08-22)
------------------

0.3.0 (2014-08-16)
------------------
* First indigo release
