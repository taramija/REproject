^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_arm
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.3 (2014-09-20)
------------------
* Add turtlebot_arm_block_manipulation package

0.3.2 (2014-08-30)
------------------

0.3.1 (2014-08-22)
------------------
* Add a metapackage

0.3.0 (2014-08-22)
------------------
* First indigo release
