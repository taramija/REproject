^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_arm_block_manipulation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.3 (2014-09-20)
------------------
* Updated version for indigo/moveit of the old turtlebot_block_manipulation

Forthcoming
-----------
* Add install rules
* Comment properly and other minor tweaks to improve pickup
* Allow user restarting, for the case that the block detection fails
* Reorganize and rename demo files to work with moveit
* Fully working and cleaned.
* Ready to try!
* Addapting turtlebot_arm_block_manipulation package to work with moveit
  (still a lot to do)
* Contributors: corot

0.3.2 (2014-08-30)
------------------

0.3.1 (2014-08-22)
------------------

0.3.0 (2014-08-17)
------------------
